package com.kh.practice.snack.run;

import com.kh.practice.snack.view.SnackMenu;

public class Run {
	public static void main(String[] args) {
		new SnackMenu().menu();
		
		
	}

}
